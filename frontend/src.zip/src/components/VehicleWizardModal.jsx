import { useEffect, useRef, useState } from 'react';
import { analyzeVehicleImage, addVehicleImage, registerVehicle, updateVehicle } from '../api/expo';
import './VehicleWizardModal.css';

const STEPS = [
  { id: 1, label: '기본 정보' },
  { id: 2, label: '이미지 업로드' },
  { id: 3, label: 'AI 자동 분석' },
  { id: 4, label: '차량 정보 확인' },
  { id: 5, label: '추가 정보' },
];

function emptyForm() {
  return {
    name: '',
    brand: '',
    category: '',
    tagsText: '',
    startPrice: '',
    range: '',
    battery: '',
    power: '',
    drivetrain: '',
    chargingType: '',
    chargingTime: '',
    dimensions: '',
    weight: '',
    seatingCapacity: '',
    summary: '',
    description: '',
    features: '',
    colors: '',
  };
}

function vehicleToForm(vehicle) {
  return {
    name: vehicle.name ?? '',
    brand: vehicle.brand ?? '',
    category: vehicle.category ?? '',
    tagsText: (vehicle.tags ?? []).join(', '),
    startPrice: vehicle.startPrice != null ? String(vehicle.startPrice) : '',
    range: vehicle.range ?? '',
    battery: vehicle.battery ?? '',
    power: vehicle.power ?? '',
    drivetrain: vehicle.drivetrain ?? '',
    chargingType: vehicle.chargingType ?? '',
    chargingTime: vehicle.chargingTime ?? '',
    dimensions: vehicle.dimensions ?? '',
    weight: vehicle.weight ?? '',
    seatingCapacity: vehicle.seatingCapacity != null ? String(vehicle.seatingCapacity) : '',
    summary: vehicle.summary ?? '',
    description: vehicle.description ?? '',
    features: vehicle.features ?? '',
    colors: vehicle.colors ?? '',
  };
}

// 부스 차량 등록/수정 5단계 마법사.
// 기본정보 -> 이미지 업로드 -> AI 자동분석(Gemini Vision) -> 결과 확인/수정 -> 추가정보 -> 저장
function VehicleWizardModal({ boothId, vehicle, onClose, onSaved }) {
  const isEdit = Boolean(vehicle);
  const [step, setStep] = useState(1);
  const [form, setForm] = useState(() => (isEdit ? vehicleToForm(vehicle) : emptyForm()));

  const [imageFile, setImageFile] = useState(null);
  const [imagePreviewUrl, setImagePreviewUrl] = useState(null);

  const [analyzing, setAnalyzing] = useState(false);
  const [analyzed, setAnalyzed] = useState(false);
  const [analyzeError, setAnalyzeError] = useState(null);
  const analysisTriggered = useRef(false);

  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState(null);
  const [stepError, setStepError] = useState(null);

  useEffect(() => {
    return () => {
      if (imagePreviewUrl) URL.revokeObjectURL(imagePreviewUrl);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleField = (field) => (e) => {
    const value = e.target.value;
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleImageSelect = (e) => {
    const file = e.target.files?.[0] ?? null;
    if (imagePreviewUrl) URL.revokeObjectURL(imagePreviewUrl);
    setImageFile(file);
    setImagePreviewUrl(file ? URL.createObjectURL(file) : null);
    setAnalyzed(false);
    setAnalyzeError(null);
    analysisTriggered.current = false;
  };

  const runAnalysis = async () => {
    if (!imageFile || analysisTriggered.current) return;
    analysisTriggered.current = true;
    setAnalyzing(true);
    setAnalyzeError(null);
    try {
      const result = await analyzeVehicleImage(boothId, imageFile);
      if (result?.analyzed) {
        setAnalyzed(true);
        setForm((prev) => ({
          ...prev,
          name: prev.name || result.name || '',
          brand: prev.brand || result.brand || '',
          category: prev.category || result.category || '',
          tagsText: prev.tagsText || (result.tags ?? []).join(', '),
          range: result.range ?? prev.range,
          battery: result.battery ?? prev.battery,
          power: result.power ?? prev.power,
          drivetrain: result.drivetrain ?? prev.drivetrain,
          chargingType: result.chargingType ?? prev.chargingType,
          chargingTime: result.chargingTime ?? prev.chargingTime,
          dimensions: result.dimensions ?? prev.dimensions,
          weight: result.weight ?? prev.weight,
          seatingCapacity:
            result.seatingCapacity != null ? String(result.seatingCapacity) : prev.seatingCapacity,
          summary: prev.summary || result.summary || '',
          description: prev.description || result.description || '',
          features: prev.features || result.features || '',
          colors: prev.colors || result.colors || '',
        }));
      } else {
        setAnalyzed(false);
        setAnalyzeError('AI가 사진에서 차량 정보를 추출하지 못했어요. 아래에서 직접 입력해주세요.');
      }
    } catch (err) {
      setAnalyzed(false);
      setAnalyzeError(
        err.response?.data?.error?.message ?? 'AI 분석 중 오류가 발생했어요. 직접 입력해주세요.'
      );
    } finally {
      setAnalyzing(false);
    }
  };

  const goNext = () => {
    setStepError(null);

    if (step === 1) {
      if (!form.name.trim() || !form.startPrice) {
        setStepError('차량명과 시작 가격은 필수 항목입니다.');
        return;
      }
    }

    if (step === 2) {
      setStep(3);
      if (imageFile) {
        runAnalysis().then(() => setStep(4));
      } else {
        setStep(4);
      }
      return;
    }

    if (step === 4) {
      if (!form.summary.trim() || !form.description.trim()) {
        setStepError('요약과 설명은 필수 항목입니다.');
        return;
      }
    }

    setStep((s) => Math.min(s + 1, STEPS.length));
  };

  const goPrev = () => {
    setStepError(null);
    if (step === 3) {
      setStep(2);
      return;
    }
    setStep((s) => Math.max(s - 1, 1));
  };

  const buildPayload = () => ({
    name: form.name.trim(),
    tags: form.tagsText.split(',').map((t) => t.trim()).filter(Boolean),
    startPrice: Number(form.startPrice),
    summary: form.summary.trim(),
    description: form.description.trim(),
    features: form.features.trim() || null,
    colors: form.colors.trim() || null,
    range: form.range.trim() || null,
    battery: form.battery.trim() || null,
    power: form.power.trim() || null,
    brand: form.brand.trim() || null,
    category: form.category.trim() || null,
    drivetrain: form.drivetrain.trim() || null,
    chargingType: form.chargingType.trim() || null,
    chargingTime: form.chargingTime.trim() || null,
    dimensions: form.dimensions.trim() || null,
    weight: form.weight.trim() || null,
    seatingCapacity: form.seatingCapacity ? Number(form.seatingCapacity) : null,
  });

  const handleSubmit = async () => {
    if (!form.summary.trim() || !form.description.trim()) {
      setStep(4);
      setStepError('요약과 설명은 필수 항목입니다.');
      return;
    }

    setSaving(true);
    setSaveError(null);
    try {
      const payload = buildPayload();
      const saved = isEdit
        ? await updateVehicle(boothId, vehicle.vehicleId, payload)
        : await registerVehicle(boothId, payload);

      if (imageFile) {
        try {
          await addVehicleImage(boothId, saved.vehicleId, imageFile);
        } catch {
          // 이미지 첨부는 실패해도 차량 등록 자체는 이미 성공했으므로 무시하고 진행
        }
      }

      onSaved(saved);
    } catch (err) {
      setSaveError(err.response?.data?.error?.message ?? '저장에 실패했습니다.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="vw-backdrop" onClick={onClose}>
      <div className="vw-modal" onClick={(e) => e.stopPropagation()}>
        <button type="button" className="vw-close" onClick={onClose} aria-label="닫기">
          ×
        </button>

        <h2>{isEdit ? '차량 정보 수정' : '차량 등록'}</h2>

        <ol className="vw-steps">
          {STEPS.map((s) => (
            <li
              key={s.id}
              className={
                'vw-steps__item' +
                (s.id === step ? ' is-active' : '') +
                (s.id < step ? ' is-done' : '')
              }
            >
              <span className="vw-steps__dot">{s.id < step ? '✓' : s.id}</span>
              <span className="vw-steps__label">{s.label}</span>
            </li>
          ))}
        </ol>

        <div className="vw-body">
          {step === 1 && (
            <div className="vw-grid">
              <label className="vw-field">
                <span>차량명 *</span>
                <input value={form.name} onChange={handleField('name')} placeholder="예: 아이오닉 5" />
              </label>
              <label className="vw-field">
                <span>브랜드</span>
                <input value={form.brand} onChange={handleField('brand')} placeholder="예: 현대" />
              </label>
              <label className="vw-field">
                <span>카테고리</span>
                <input
                  value={form.category}
                  onChange={handleField('category')}
                  placeholder="예: SUV, 세단"
                />
              </label>
              <label className="vw-field">
                <span>태그 (쉼표로 구분)</span>
                <input
                  value={form.tagsText}
                  onChange={handleField('tagsText')}
                  placeholder="전기차, SUV"
                />
              </label>
              <label className="vw-field">
                <span>시작 가격 *</span>
                <input
                  type="number"
                  value={form.startPrice}
                  onChange={handleField('startPrice')}
                  placeholder="52400000"
                />
              </label>
            </div>
          )}

          {step === 2 && (
            <div className="vw-upload">
              <p className="vw-upload__desc">
                차량 사진을 올리면 AI가 사진을 분석해서 다음 단계 차량 정보를 자동으로 채워줘요.
                사진이 없으면 건너뛰고 직접 입력할 수 있어요.
              </p>
              <div className="vw-upload__row">
                <div className="vw-upload__preview">
                  {imagePreviewUrl ? (
                    <img src={imagePreviewUrl} alt="차량 미리보기" />
                  ) : (
                    <span>사진 없음</span>
                  )}
                </div>
                <label className="vw-upload__button">
                  사진 선택
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/webp"
                    onChange={handleImageSelect}
                    hidden
                  />
                </label>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="vw-analyzing">
              <span className="vw-analyzing__spinner" aria-hidden="true" />
              <h3>AI가 차량 사진을 분석하고 있어요</h3>
              <p>잠시만 기다려주세요. 배터리, 주행거리, 출력 등 상세 스펙을 추출하고 있어요.</p>
            </div>
          )}

          {step === 4 && (
            <div className="vw-grid">
              {analyzed && (
                <p className="vw-hint vw-hint--ok">
                  AI가 사진을 분석해서 아래 값을 채웠어요. 내용을 확인하고 필요하면 수정해주세요.
                </p>
              )}
              {analyzeError && <p className="vw-hint vw-hint--warn">{analyzeError}</p>}

              <label className="vw-field vw-field--wide">
                <span>요약 *</span>
                <input value={form.summary} onChange={handleField('summary')} placeholder="한 줄 요약" />
              </label>
              <label className="vw-field">
                <span>1회 충전 주행거리</span>
                <input value={form.range} onChange={handleField('range')} placeholder="458 km" />
              </label>
              <label className="vw-field">
                <span>배터리 용량</span>
                <input value={form.battery} onChange={handleField('battery')} placeholder="77.4 kWh" />
              </label>
              <label className="vw-field">
                <span>최대 출력</span>
                <input value={form.power} onChange={handleField('power')} placeholder="325 ps" />
              </label>
              <label className="vw-field">
                <span>구동 방식</span>
                <input
                  value={form.drivetrain}
                  onChange={handleField('drivetrain')}
                  placeholder="AWD"
                />
              </label>
              <label className="vw-field">
                <span>충전 방식</span>
                <input
                  value={form.chargingType}
                  onChange={handleField('chargingType')}
                  placeholder="DC 콤보"
                />
              </label>
              <label className="vw-field">
                <span>충전 시간</span>
                <input
                  value={form.chargingTime}
                  onChange={handleField('chargingTime')}
                  placeholder="18분(10~80%)"
                />
              </label>
              <label className="vw-field">
                <span>크기 (전장x전폭x전고)</span>
                <input
                  value={form.dimensions}
                  onChange={handleField('dimensions')}
                  placeholder="4635x1890x1620mm"
                />
              </label>
              <label className="vw-field">
                <span>무게</span>
                <input value={form.weight} onChange={handleField('weight')} placeholder="2100 kg" />
              </label>
              <label className="vw-field">
                <span>승차 인원</span>
                <input
                  type="number"
                  value={form.seatingCapacity}
                  onChange={handleField('seatingCapacity')}
                  placeholder="5"
                />
              </label>
              <label className="vw-field vw-field--wide">
                <span>설명 *</span>
                <textarea
                  rows={3}
                  value={form.description}
                  onChange={handleField('description')}
                  placeholder="전시 소개용 상세 설명"
                />
              </label>
            </div>
          )}

          {step === 5 && (
            <div className="vw-grid">
              <label className="vw-field vw-field--wide">
                <span>주요 특징</span>
                <textarea
                  rows={3}
                  value={form.features}
                  onChange={handleField('features')}
                  placeholder="차량의 주요 특징을 입력해주세요."
                />
              </label>
              <label className="vw-field vw-field--wide">
                <span>컬러</span>
                <textarea
                  rows={2}
                  value={form.colors}
                  onChange={handleField('colors')}
                  placeholder="선택 가능한 컬러를 입력해주세요."
                />
              </label>
              {saveError && <p className="vw-hint vw-hint--error">{saveError}</p>}
            </div>
          )}
        </div>

        {stepError && <p className="vw-hint vw-hint--error">{stepError}</p>}

        <div className="vw-actions">
          {step > 1 && step !== 3 && (
            <button type="button" className="vw-btn vw-btn--ghost" onClick={goPrev} disabled={saving}>
              이전
            </button>
          )}
          {step === 2 && (
            <button
              type="button"
              className="vw-btn vw-btn--ghost"
              onClick={() => {
                setImageFile(null);
                setImagePreviewUrl(null);
                setStep(4);
              }}
            >
              건너뛰기
            </button>
          )}
          {step < 5 && step !== 3 && (
            <button type="button" className="vw-btn" onClick={goNext}>
              다음
            </button>
          )}
          {step === 5 && (
            <button type="button" className="vw-btn" disabled={saving} onClick={handleSubmit}>
              {saving ? '저장 중...' : isEdit ? '수정 완료' : '등록하기'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export default VehicleWizardModal;