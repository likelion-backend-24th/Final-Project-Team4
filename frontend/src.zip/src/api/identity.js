import apiClient from "./client";

// GET /api/auth/me - 로그인한 사용자의 업체 및 담당자 정보
export const getMyProfile = () =>
  apiClient.get("/api/auth/me").then((res) => res.data.data);

// DELETE /api/auth/me - 회원 탈퇴(soft delete)
export const withdrawAccount = () => apiClient.delete("/api/auth/me");

// PATCH /api/auth/me - 일반회원 정보 수정 (이름/휴대폰 번호)
export const updateMyProfile = (data) =>
  apiClient.patch("/api/auth/me", data).then((res) => res.data.data);

// PATCH /api/auth/exhibitors/me - 참가업체 정보 수정
export const updateExhibitorProfile = (data) =>
  apiClient.patch("/api/auth/exhibitors/me", data).then((res) => res.data.data);

// POST /api/auth/password-reset - 재설정 링크 발송 요청
export const requestPasswordReset = (email) =>
  apiClient.post("/api/auth/password-reset", { email }, { skipAuthRefresh: true });

// POST /api/auth/password-reset/confirm - 링크 토큰 + 새 비밀번호로 실제 변경
export const confirmPasswordReset = (token, newPassword) =>
  apiClient.post(
    "/api/auth/password-reset/confirm",
    { token, newPassword },
    { skipAuthRefresh: true },
  );

// POST /api/auth/email-verification/code - 회원가입 전 이메일 인증 코드 발송
export const sendVerificationCode = (email) =>
  apiClient.post(
    "/api/auth/email-verification/code",
    { email },
    { skipAuthRefresh: true },
  );

// POST /api/auth/email-verification/confirm - 인증 코드 확인
export const confirmVerificationCode = (email, code) =>
  apiClient.post(
    "/api/auth/email-verification/confirm",
    { email, code },
    { skipAuthRefresh: true },
  );
