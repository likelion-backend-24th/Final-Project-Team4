import apiClient from "./client";
import { getUserId } from "./auth";

// POST /api/exhibitor/payments - 부스 참가비 결제
// bookingId = 신청 그룹 id. amount = payment-context의 결제 대상 합계와 정확히 일치해야 함.
// paymentId = PortOne 결제창에서 실제로 처리된 결제 건의 고유 ID (프론트에서 미리 만들어서 넘긴 값)
export const payGroup = ({ groupId, amount, payMethod, paymentId }) =>
  apiClient
    .post("/api/exhibitor/payments", {
      bookingId: groupId,
      userId: getUserId(),
      amount,
      payMethod,
      paymentId,
    })
    .then((res) => res.data);

// GET /api/exhibitor/payments?userId=... - 로그인한 사용자의 결제 내역 전체 조회
// 마이페이지 "참가비 결제 내역" 표에서 사용
export const getMyPayments = () =>
  apiClient
    .get("/api/exhibitor/payments", { params: { userId: getUserId() } })
    .then((res) => res.data);