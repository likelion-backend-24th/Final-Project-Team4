package com.team4.payment.Repository;

import com.team4.payment.Entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PaymentRepository extends JpaRepository<Payment, Long> {

    // 예약(bookingId) 기준으로 결제 내역 조회 (마이 페이지 결제 상태 확인용)
    Optional<Payment> findByBookingId(Long bookingId);
    // 이 예약에 대해 이미 결제 건이 존재하는지 확인 (중복 결제 방지)
    boolean existsBookingId(Long bookingId);


    // 포트원 거래 고유 번호로 조회
    Optional<Payment> findByPortonePaymentId(String portonePaymentId);
    // 거래 고유 번호 중복 여부 확인
    boolean existsByPortonePaymentId(String portonePaymentId);
}
