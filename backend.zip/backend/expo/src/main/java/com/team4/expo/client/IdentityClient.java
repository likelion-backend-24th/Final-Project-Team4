package com.team4.expo.client;

import java.util.Optional;

public class IdentityClient {
    Optional<ExhibitorProfile> getExhibitorProfile(Long userId);
}
