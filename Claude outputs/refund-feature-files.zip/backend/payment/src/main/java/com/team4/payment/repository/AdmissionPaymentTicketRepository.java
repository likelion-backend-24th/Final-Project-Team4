package com.team4.payment.repository;

import com.team4.payment.entity.AdmissionPaymentTicket;
import java.util.Optional;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdmissionPaymentTicketRepository extends JpaRepository<AdmissionPaymentTicket, Long> {

    // ticketId = Reservation 서비스 Ticket.id 논리 참조. 결제 내역 조회·환불 처리 양쪽에서 쓴다.
    // 조회 즉시 소유자(customerId) 확인을 위해 부모 AdmissionPayment까지 같이 가져온다(N+1 방지).
    @EntityGraph(attributePaths = "admissionPayment")
    Optional<AdmissionPaymentTicket> findByTicketId(Long ticketId);
}
