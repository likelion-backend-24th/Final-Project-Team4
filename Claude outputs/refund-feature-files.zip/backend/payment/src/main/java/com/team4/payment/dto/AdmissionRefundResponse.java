package com.team4.payment.dto;

import java.time.LocalDateTime;

// 환불 신청 처리 결과. refundFee는 지금은 항상 0(전액 환불)이지만, 나중에 "방문일 임박 시 수수료 부과" 같은
// 정책이 생기면 이 필드만 채우면 되도록 미리 응답에 넣어둠.
public record AdmissionRefundResponse(
        Long ticketId,
        Long refundAmount,
        Long refundFee,
        String status,
        LocalDateTime refundedAt
) {
}
